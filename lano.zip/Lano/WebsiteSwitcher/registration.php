<?php
/**
 * Created by PhpStorm.
 * User: julianovargas
 * Date: 24/03/2018
 * Time: 19:37
 */

\Magento\Framework\Component\ComponentRegistrar::register(
        \Magento\Framework\Component\ComponentRegistrar::MODULE,
        'Lano_WebsiteSwitcher',
        __DIR__
    );
?>
