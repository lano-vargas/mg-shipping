var config = {
    "map": {
        "*": {
            "websiteSwitcher": "Lano_WebsiteSwitcher/js/switcher"
        }
    }
};